#!/bin/bash
set -e -u -x

./get_nanoversion.sh
cp -a ../src .
